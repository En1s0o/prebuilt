CREATE TABLE tab_sample (
  alpha bigint(20) DEFAULT NULL AUTO_INCREMENT,
  beta tinyint(1) DEFAULT NULL,
  gamma varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
