#include <sqlpp11/sqlpp11.h>

int Minimalistic(int /*unused*/, char* /*unused*/ [])
{
  return 0;
}
